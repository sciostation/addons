import sys
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc

# Constantes del addon
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]

# URL del sitio de La Tele
LEGENDARIUM_URL = "https://mindsofmachine-machine.static.hf.space/index.html"

# Funci�n para mostrar la interfaz web en un WebViewer
def open_legendarium():
    xbmc.executebuiltin(f'RunPlugin({LEGENDARIUM_URL})')

# Manejo del addon
def router(paramstring):
    params = dict(arg.split('=') for arg in paramstring.split('&'))
    if params:
        if params['action'] == 'open':
            open_legendarium()
    else:
        list_menu()

# Funci�n para mostrar el men� principal
def list_menu():
    url = f'{addon_url}?action=open'
    li = xbmcgui.ListItem('Abrir La Tele')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

if __name__ == '__main__':
    router(sys.argv[2][1:])
